﻿
namespace FlashCards.ViewModel
{
    public class AudioMetaData : MetaData
    {
    }
}
