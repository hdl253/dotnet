﻿Imports System
Imports System.Security
Imports System.Security.Principal
Imports System.Web
Imports System.Web.Mvc
Imports System.Web.Routing
Imports System.Web.Security
Imports Microsoft.VisualStudio.TestTools.UnitTesting

Imports Mvc3RemoteVal

<TestClass()> Public Class HomeControllerTest

    <TestMethod()>
    Public Sub Index_Get_AsksForIndexView()
        ' Arrange
        Dim controller = GetHomeController(New InMemoryDB())
        ' Act
        Dim result As ViewResult = controller.Index()
        ' Assert
        Assert.AreEqual("Index", result.ViewName)
    End Sub

    <TestMethod()>
    Public Sub Index_Get_RetrievesAllUsersFromRepository()
        ' Arrange
        Dim udb = New InMemoryDB()
        Dim controller = GetHomeController(udb)

        ' Act
        Dim result = controller.Index()

        ' Assert
        Dim model = CType(result.ViewData.Model, IEnumerable(Of User))

        For Each usr As User In udb.GetAllUsers
            CollectionAssert.Contains(model.ToList(), usr)
        Next usr
    End Sub

    <TestMethod()>
    Public Sub Create_Post_PutsValidUserIntoRepository()
        ' Arrange
        Dim udb = New InMemoryDB()
        Dim controller = GetHomeController(udb)
        Dim joe = CreateUserJoe()
        ' Act
        controller.Create(joe)

        ' Assert
        Dim users As IEnumerable(Of User) = udb.GetAllUsers
        Dim joeUsr As User = Nothing
        For Each usr As User In udb.GetAllUsers
            If usr.UserName.Equals(_joe) Then
                joeUsr = usr
            End If
        Next usr


        Assert.IsTrue(joeUsr.FirstName.Equals(joe.FirstName))
    End Sub
    <TestMethod()>
    Public Sub Edit_GET_BogusUserRedirectToAction_ToIndex()
        ' Arrange
        Dim udb = New InMemoryDB()
        Dim controller = GetHomeController(udb)
        Dim JoeUsr = CreateUserJoe()

        ' Act
        Dim result = TryCast(controller.Edit(JoeUsr.UserName), RedirectToRouteResult)

        ' Assert
        Assert.AreEqual("Index", result.RouteValues("action").ToString())
    End Sub

    <TestMethod()>
    Public Sub Edit_Post_UpdatesNewUserInfoIntoRepository()
        ' Arrange
        Dim udb = New InMemoryDB()
        Dim controller = GetHomeController(udb)
        Dim JoeUsr = CreateUserJoe()
        controller.Create(JoeUsr)
        ' Act
        Const newCity As String = "New City"
        JoeUsr.City = newCity

        Dim result = controller.Edit(JoeUsr)


        ' Assert
        Dim found As Boolean = False
        For Each usr As User In udb.GetAllUsers
            If usr.UserName = _joe Then
                found = True
                Assert.IsTrue(usr.City = newCity)
            End If
        Next usr

        Assert.IsTrue(found)
    End Sub

    <TestMethod()>
    Public Sub Create_Post_ReturnsViewIfModelStateIsNotValid()
        ' Arrange
        Dim controller As HomeController = GetHomeController(New InMemoryDB())
        ' Simply executing a method during a unit test does just that - executes a method, and no more. 
        ' The MVC pipeline doesn't run, so binding and validation don't run.
        controller.ModelState.AddModelError("", "mock error message")
        Dim model = CreateUserJoe()

        ' Act
        Dim result = CType(controller.Create(model), ViewResult)

        ' Assert
        Assert.AreEqual("Create", result.ViewName)
    End Sub

    <TestMethod()>
    Public Sub Create_Post_ReturnsRedirectToActionDetailsIfRepositoryThrowsException()
        ' Arrange

        Dim udb = New InMemoryDB()
        Dim controller = GetHomeController(udb)
        Dim modelJoe As CreateUserModel = CreateUserJoe()

        ' Act
        Dim result = controller.Create(modelJoe)
        ' Add duplicate user (Add modelJoe again)
        result = controller.Create(modelJoe)
        Dim modelState_Renamed As ModelState = controller.ModelState("")

        '// Assert

        Assert.IsNotNull(modelState_Renamed)
        Assert.IsTrue(modelState_Renamed.Errors.Any())
        Dim strError As String = modelState_Renamed.Errors(0).ErrorMessage
        Assert.IsTrue(strError.Contains("Create Failure, try another user name or"))
    End Sub



    <TestMethod()>
    Public Sub Details_Get_ReturnsRequestedUser()
        ' Arrange
        Dim udb = New InMemoryDB()
        Dim controller = GetHomeController(udb)
        Dim joe = CreateUserJoe()

        ' Act
        controller.Create(joe)
        Dim result = CType(controller.Details(joe.UserName), ViewResult)

        ' Assert
        Dim model = CType(result.ViewData.Model, User)
        Assert.IsTrue(model.UserName.CompareTo(joe.UserName) = 0)
    End Sub

    <TestMethod()>
    Public Sub Details_GET_BogusUserRedirectToAction_ToIndex()
        ' Arrange
        Dim udb = New InMemoryDB()
        Dim controller = GetHomeController(udb)
        Dim JoeUsr = CreateUserJoe()

        ' Act
        Dim result = TryCast(controller.Details(JoeUsr.UserName), RedirectToRouteResult)

        ' Assert
        Assert.AreEqual("Index", result.RouteValues("action").ToString())
    End Sub

    <TestMethod()>
    Public Sub Details_Get_AsksForDetailsView()
        ' Arrange
        Dim udb = New InMemoryDB()
        Dim controller = GetHomeController(udb)
        ' Act
        Dim result = CType(controller.Details("BenM"), ViewResult)
        ' Assert
        Assert.AreEqual("Details", result.ViewName)
    End Sub

    <TestMethod()>
    Public Sub Delete_Post_ReturnsRedirectOnSuccess()
        ' Arrange
        Dim controller As HomeController = GetHomeController(New InMemoryDB())
        Dim model As CreateUserModel = CreateUserJoe()

        ' Act
        Dim result = controller.Create(model)

        ' Assert
        Assert.IsNotNull(result)
        ' Act
        Dim resultD = CType(controller.Delete(model.UserName, New FormCollection()), RedirectToRouteResult)

        ' Assert
        Assert.AreEqual("Index", resultD.RouteValues("action"))
    End Sub

    Public Sub Delete_Post_DeletesUser()
        ' Arrange
        Dim udb = New InMemoryDB()
        Dim controller As HomeController = GetHomeController(udb)
        Dim model As CreateUserModel = CreateUserJoe()

        ' Act
        Dim result = controller.Create(model)

        ' Assert
        Assert.IsNotNull(result)
        CollectionAssert.Contains(udb.GetAllUsers, model)
        ' Act
        Dim resultD = CType(controller.Delete(model.UserName, New FormCollection()), RedirectToRouteResult)

        ' Assert
        CollectionAssert.DoesNotContain(udb.GetAllUsers, model)
    End Sub

    <TestMethod()>
    Public Sub About()
        ' Arrange
        Dim controller = GetHomeController(New InMemoryDB())

        ' Act
        Dim result As ViewResult = TryCast(controller.About(), ViewResult)

        ' Assert
        Assert.IsNotNull(result)
    End Sub

    Private Const _joe As String = "JoeS"
    Private Function CreateUserJoe() As CreateUserModel
        Return New CreateUserModel With {.UserName = _joe, .FirstName = "Joe", .LastName = "Smith", .City = "SLC"}
    End Function

    Private Function EditMdlUserJoe() As EditUserModel
        Return New EditUserModel With {.UserName = _joe, .FirstName = "Joe", .LastName = "Smith", .City = "SLC"}
    End Function

    Private Shared Function GetHomeController(ByVal repository As IUserDB) As HomeController
        Dim controller As New HomeController(repository)

        controller.ControllerContext = New ControllerContext() With {.Controller = controller, .RequestContext = New RequestContext(New MockHttpContext(), New RouteData())}
        Return controller
    End Function



    Private Class MockHttpContext
        Inherits HttpContextBase
        Private ReadOnly _user As IPrincipal = New GenericPrincipal(New GenericIdentity("someUser"), Nothing) ' roles

        Public Overrides Property User() As IPrincipal
            Get
                Return _user
            End Get
            Set(ByVal value As IPrincipal)
                MyBase.User = value
            End Set
        End Property
    End Class
End Class
