﻿Public Class HomeController
    Inherits System.Web.Mvc.Controller

    Private _repository As IUserDB

#If InMemDB Then
		Public Sub New()
			Me.New(InMemoryDB.Instance)
		End Sub
#Else
    Public Sub New()
        Me.New(New EF_UserRepository())
    End Sub
#End If


    Public Sub New(ByVal repository As IUserDB)
        _repository = repository
    End Sub

    Public Function Index() As ViewResult
        Return View("Index", _repository.GetAllUsers)
    End Function

    Public Function Details(ByVal id As String) As ActionResult
        Dim user_Renamed As User = _repository.GetUser(id)
        If user_Renamed Is Nothing Then
            Return RedirectToAction("Index")
        End If

        Return View("Details", user_Renamed)
    End Function

    Public Function Edit(ByVal id As String) As ActionResult
        Dim user_Renamed As User = _repository.GetUser(id)
        If user_Renamed Is Nothing Then
            Return RedirectToAction("Index")
        End If

        Dim model As New EditUserModel()
        ModelCopier.CopyModel(user_Renamed, model)

        Return View(model)
    End Function

    <HttpPost()>
    Public Function Edit(ByVal model As EditUserModel) As ActionResult
        Try
            Dim user_Renamed As User = _repository.GetUser(model.UserName)
            ModelCopier.CopyModel(model, user_Renamed)
            _repository.Update(user_Renamed)

            Return RedirectToAction("Details", New With {Key .id = model.UserName})
        Catch e1 As Exception
            ModelState.AddModelError("", "Edit Failure, see inner ex")
        End Try

        Return View(model)
    End Function

    Public Function About() As ActionResult
        Return View()
    End Function

    Public Function Create() As ViewResult
        Return View(New CreateUserModel())
    End Function

    <HttpPost()>
    Public Function Create(ByVal model As CreateUserModel) As ActionResult
        Try
            If ModelState.IsValid Then
                Dim user_Renamed As New User()
                ModelCopier.CopyModel(model, user_Renamed)
                _repository.CreateNewUser(user_Renamed)

                Return RedirectToAction("Details", New With {Key .id = user_Renamed.UserName})
            End If
        Catch e1 As Exception
            ModelState.AddModelError("", "Create Failure, try another user name or" & " see inner exception")
        End Try

        Return View("Create", model)
    End Function

    Public Function Delete(ByVal id As String) As ActionResult
        Dim user_Renamed As User = _repository.GetUser(id)
        If user_Renamed Is Nothing Then
            Return RedirectToAction("Index")
        End If

        Return View(user_Renamed)
    End Function

    <HttpPost()>
    Public Function Delete(ByVal id As String, ByVal collection As FormCollection) As RedirectToRouteResult
        _repository.Remove(id)
        Return RedirectToAction("Index")
    End Function
End Class