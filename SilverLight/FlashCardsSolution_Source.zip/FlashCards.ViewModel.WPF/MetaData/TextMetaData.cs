﻿
namespace FlashCards.ViewModel
{
    public class TextMetaData : MetaData
    {
    }
}
