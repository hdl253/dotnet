﻿
namespace FlashCards.ViewModel
{
    public class VideoMetaData : MetaData
    {
    }
}
