﻿
namespace FlashCards.ViewModel
{
    public class ImageMetaData : MetaData
    {
    }
}
