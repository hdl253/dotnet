﻿using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace Mvc3RemoteVal.Models {
    public class EditUserModel {
        [Editable(false)]
        public virtual string UserName { get; set; }

        [Required]
        [StringLength(18, MinimumLength = 3)]
        [Display(Name = "First Name")]
        public string FirstName { get; set; }

        [Required]
        [StringLength(9, MinimumLength = 2)]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }
        [Required()]
        public string City { get; set; }
    }

    public class CreateUserModel : EditUserModel {
        [Required]
        [StringLength(6, MinimumLength = 3)]
        [Remote("IsUID_Available", "Validation")]
        [RegularExpression(@"(\S)+", ErrorMessage = "White space is not allowed")]
        [Editable(true)]
        public override string UserName { get; set; }
    }
}