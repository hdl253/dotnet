﻿using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using Mvc3RemoteVal.Controllers;
using Mvc3RemoteVal.Models;

namespace Mvc3RemoteVal.Tests.Controllers {
    [TestClass]
    public class HomeControllerTest {

        [TestMethod]
        public void Index_Get_AsksForIndexView() {
            // Arrange
            var controller = GetHomeController(new InMemoryDB());
            // Act
            ViewResult result = controller.Index();
            // Assert
            Assert.AreEqual("Index", result.ViewName);
        }

        [TestMethod]
        public void Index_Get_RetrievesAllUsersFromRepository() {
            // Arrange
            var udb = new InMemoryDB();
            var controller = GetHomeController(udb);

            // Act
            var result = controller.Index();

            // Assert
            var model = (IEnumerable<User>)result.ViewData.Model;

            foreach (User usr in udb.GetAllUsers)
                CollectionAssert.Contains(model.ToList(), usr);
        }

        [TestMethod]
        public void Create_Post_PutsValidUserIntoRepository() {
            // Arrange
            var udb = new InMemoryDB();
            var controller = GetHomeController(udb);
            var joe = CreateUserJoe();
            // Act
            controller.Create(joe);

            // Assert
            IEnumerable<User> users = udb.GetAllUsers;
            User joeUsr = null;
            foreach (User usr in udb.GetAllUsers)
                if (usr.UserName.Equals(_joe))
                    joeUsr = usr;


            Assert.IsTrue(joeUsr.FirstName.Equals(joe.FirstName));
        }
        [TestMethod]
        public void Edit_GET_BogusUserRedirectToAction_ToIndex() {
            // Arrange
            var udb = new InMemoryDB();
            var controller = GetHomeController(udb);
            var JoeUsr = CreateUserJoe();
           
            // Act
            var result = controller.Edit(JoeUsr.UserName) as RedirectToRouteResult;

            // Assert
            Assert.AreEqual("Index", result.RouteValues["action"].ToString());
        }

        [TestMethod]
        public void Edit_Post_UpdatesNewUserInfoIntoRepository() {
            // Arrange
            var udb = new InMemoryDB();
            var controller = GetHomeController(udb);
            var JoeUsr = CreateUserJoe();
            controller.Create(JoeUsr);
            // Act
            const string newCity = "New City";
            JoeUsr.City = newCity;

            var result = controller.Edit(JoeUsr);


            // Assert
            bool found = false;
            foreach (User usr in udb.GetAllUsers)
                if (usr.UserName == _joe) {
                    found = true;
                    Assert.IsTrue(usr.City == newCity);
                }

            Assert.IsTrue(found);
        }

        [TestMethod]
        public void Create_Post_ReturnsViewIfModelStateIsNotValid() {
            // Arrange
            HomeController controller = GetHomeController(new InMemoryDB());
            // Simply executing a method during a unit test does just that - executes a method, and no more. 
            // The MVC pipeline doesn't run, so binding and validation don't run.
            controller.ModelState.AddModelError("", "mock error message");
            var model = CreateUserJoe();

            // Act
            var result = (ViewResult)controller.Create(model);

            // Assert
            Assert.AreEqual("Create", result.ViewName);
        }

        [TestMethod]
        public void Create_Post_ReturnsRedirectToActionDetailsIfRepositoryThrowsException() {
            // Arrange

            var udb = new InMemoryDB();
            var controller = GetHomeController(udb);
            CreateUserModel modelJoe = CreateUserJoe();

            // Act
            var result = controller.Create(modelJoe);
            // Add duplicate user (Add modelJoe again)
            result = controller.Create(modelJoe);
            ModelState modelState = controller.ModelState[""];

            //// Assert

            Assert.IsNotNull(modelState);
            Assert.IsTrue(modelState.Errors.Any());
            string strError = modelState.Errors[0].ErrorMessage;
            Assert.IsTrue(strError.Contains("Create Failure, try another user name or"));
        }

      

        [TestMethod]
        public void Details_Get_ReturnsRequestedUser() {
            // Arrange
            var udb = new InMemoryDB();
            var controller = GetHomeController(udb);
            var joe = CreateUserJoe();

            // Act
            controller.Create(joe);
            var result = (ViewResult)controller.Details(joe.UserName);

            // Assert
            var model = (User)result.ViewData.Model;
            Assert.IsTrue(model.UserName.CompareTo(joe.UserName) == 0);
        }

        [TestMethod]
        public void Details_GET_BogusUserRedirectToAction_ToIndex() {
            // Arrange
            var udb = new InMemoryDB();
            var controller = GetHomeController(udb);
            var JoeUsr = CreateUserJoe();

            // Act
            var result = controller.Details(JoeUsr.UserName) as RedirectToRouteResult;

            // Assert
            Assert.AreEqual("Index", result.RouteValues["action"].ToString());
        }

        [TestMethod]
        public void Details_Get_AsksForDetailsView() {
            // Arrange
            var udb = new InMemoryDB();
            var controller = GetHomeController(udb);
            // Act
            var result = (ViewResult)controller.Details("BenM");
            // Assert
            Assert.AreEqual("Details", result.ViewName);
        }

        [TestMethod]
        public void Delete_Post_ReturnsRedirectOnSuccess() {
            // Arrange
            HomeController controller = GetHomeController(new InMemoryDB());
            CreateUserModel model = CreateUserJoe();

            // Act
            var result = controller.Create(model);

            // Assert
            Assert.IsNotNull(result);
            // Act
            var resultD = (RedirectToRouteResult)controller.Delete(model.UserName,
                new FormCollection());

            // Assert
            Assert.AreEqual("Index", resultD.RouteValues["action"]);
        }

        public void Delete_Post_DeletesUser() {
            // Arrange
            var udb = new InMemoryDB();
            HomeController controller = GetHomeController(udb);
            CreateUserModel model = CreateUserJoe();

            // Act
            var result = controller.Create(model);

            // Assert
            Assert.IsNotNull(result);
            CollectionAssert.Contains(udb.GetAllUsers, model);
            // Act
            var resultD = (RedirectToRouteResult)controller.Delete(model.UserName,
                new FormCollection());

            // Assert
            CollectionAssert.DoesNotContain(udb.GetAllUsers, model);
        }

        [TestMethod]
        public void About() {
            // Arrange
            var controller = GetHomeController(new InMemoryDB());

            // Act
            ViewResult result = controller.About() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }

        const string _joe = "JoeS";
        CreateUserModel CreateUserJoe() {
            return new CreateUserModel
            {
                UserName = _joe,
                FirstName = "Joe",
                LastName = "Smith",
                City = "SLC"
            };
        }

        EditUserModel EditMdlUserJoe() {
            return new EditUserModel
            {
                UserName = _joe,
                FirstName = "Joe",
                LastName = "Smith",
                City = "SLC"
            };
        }

        private static HomeController GetHomeController(IUserDB repository) {
            HomeController controller = new HomeController(repository);

            controller.ControllerContext = new ControllerContext()
            {
                Controller = controller,
                RequestContext = new RequestContext(new MockHttpContext(), new RouteData())
            };
            return controller;
        }



        private class MockHttpContext : HttpContextBase {
            // ToDo: Mock JSON value provider so you can use/test  TryUpdateModel 
            private readonly IPrincipal _user = new GenericPrincipal(new GenericIdentity("someUser"), null /* roles */);

            public override IPrincipal User {
                get {
                    return _user;
                }
                set {
                    base.User = value;
                }
            }
        }
    }
}
