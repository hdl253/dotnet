﻿Imports System.Globalization
Imports System.Web.Mvc
Imports System.Web.UI

Namespace Mvc3RemoteVal
    <OutputCache(Location:=OutputCacheLocation.None, NoStore:=True)>
    Public Class ValidationController
        Inherits Controller

        Private _repository As IUserDB
#If InMemDB Then
        Public Sub New()
            Me.New(InMemoryDB.Instance)
        End Sub
#Else
		  Public Sub New()
			  Me.New(New EF_UserRepository())
		  End Sub
#End If


        Public Sub New(ByVal repository As IUserDB)
            _repository = repository
        End Sub

        Public Function IsUID_Available(ByVal Username As String) As JsonResult

            If Not _repository.UserExists(Username) Then
                Return Json(True, JsonRequestBehavior.AllowGet)
            End If

            Dim suggestedUID As String = String.Format(CultureInfo.InvariantCulture, "{0} is not available.", Username)

            For i As Integer = 1 To 99
                Dim altCandidate As String = Username & i.ToString()
                If Not _repository.UserExists(altCandidate) Then
                    suggestedUID = String.Format(CultureInfo.InvariantCulture, "{0} is not available. Try {1}.", Username, altCandidate)
                    Exit For
                End If
            Next i
            Return Json(suggestedUID, JsonRequestBehavior.AllowGet)
        End Function

    End Class
End Namespace
